import java.util.ArrayList;
import java.util.List;

/**
 * Implementacao do algoritmo guloso (greedy) para o Problema do Troco.
 *
 * Estrategia gulosa: a cada passo, escolhe-se a MAIOR moeda disponivel que
 * seja menor ou igual ao valor restante a trocar, usando-a quantas vezes
 * for possivel antes de passar para a proxima moeda (escolha local).
 *
 * Esta classe NAO utiliza nenhuma biblioteca pronta de resolucao do
 * problema do troco: a logica abaixo e inteiramente escrita por nos.
 */
public class TrocoGuloso {

    /** Um passo de decisao do algoritmo, usado para montar o rastro (trace) de debug. */
    public static class PassoDecisao {
        public final long moeda;
        public final long quantidadeUsada;
        public final long valorRestanteAntes;
        public final long valorRestanteDepois;

        PassoDecisao(long moeda, long quantidadeUsada, long valorRestanteAntes, long valorRestanteDepois) {
            this.moeda = moeda;
            this.quantidadeUsada = quantidadeUsada;
            this.valorRestanteAntes = valorRestanteAntes;
            this.valorRestanteDepois = valorRestanteDepois;
        }

        @Override
        public String toString() {
            return String.format(
                "Resto antes = %d  ->  escolhe a moeda %d (maior <= resto)  ->  usa %d unidade(s)  ->  resto depois = %d",
                valorRestanteAntes, moeda, quantidadeUsada, valorRestanteDepois);
        }
    }

    /** Resultado completo da execucao do algoritmo guloso sobre uma instancia. */
    public static class Resultado {
        public final List<PassoDecisao> passos = new ArrayList<>();
        public long valorRestanteFinal;
        public long totalDeMoedasUsadas;
        public long tempoExecucaoNanos;

        public boolean conseguiuTrocoExato() {
            return valorRestanteFinal == 0;
        }
    }

    /**
     * Resolve o problema do troco de forma gulosa.
     *
     * Condicao de parada: o valor restante chega a zero (troco exato
     * encontrado) OU nao ha mais moedas menores/iguais ao resto (nesse
     * caso o sistema de moedas nao permite troco exato para este valor
     * usando a estrategia gulosa).
     */
    public Resultado resolver(long[] moedas, long valor) {
        long inicio = System.nanoTime();

        long[] moedasOrdenadas = moedas.clone();
        ordenarDecrescente(moedasOrdenadas); // organizacao inicial dos dados: da maior para a menor

        Resultado resultado = new Resultado();
        long restante = valor;

        for (long moeda : moedasOrdenadas) {
            if (restante <= 0) {
                break;
            }
            if (moeda <= restante) {
                long quantidade = restante / moeda; // escolha gulosa: usa o maximo possivel desta moeda
                long restanteAntes = restante;
                restante -= quantidade * moeda;
                resultado.passos.add(new PassoDecisao(moeda, quantidade, restanteAntes, restante));
                resultado.totalDeMoedasUsadas += quantidade;
            }
            // moedas maiores que o restante sao descartadas (nao servem nesta etapa)
        }

        resultado.valorRestanteFinal = restante;
        resultado.tempoExecucaoNanos = System.nanoTime() - inicio;
        return resultado;
    }

    /** Ordenacao simples (insertion sort) em ordem decrescente - conjunto de moedas costuma ser pequeno. */
    private void ordenarDecrescente(long[] vetor) {
        for (int i = 1; i < vetor.length; i++) {
            long chave = vetor[i];
            int j = i - 1;
            while (j >= 0 && vetor[j] < chave) {
                vetor[j + 1] = vetor[j];
                j--;
            }
            vetor[j + 1] = chave;
        }
    }
}
