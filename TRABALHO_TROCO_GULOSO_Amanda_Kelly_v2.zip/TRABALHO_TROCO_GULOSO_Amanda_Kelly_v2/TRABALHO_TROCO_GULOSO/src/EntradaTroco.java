import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Representa os dados de entrada de uma instancia do Problema do Troco:
 * o conjunto de moedas/cedulas disponiveis (o "sistema monetario") e o
 * valor que deve ser trocado.
 *
 * Suporta carregar a partir de:
 *  - arquivo JSON contendo "moedas" (array) e "valor" (numero);
 *  - arquivo CSV contendo apenas a lista de moedas (uma por linha, com
 *    cabecalho "moeda"), caso em que o valor a trocar e informado a parte.
 *
 * Nao utiliza nenhuma biblioteca externa de parsing: a leitura e feita
 * manualmente com expressoes regulares simples, suficiente para o formato
 * de entrada usado neste trabalho.
 */
public class EntradaTroco {

    private final long[] moedas;
    private final long valor;
    private final String descricao;

    public EntradaTroco(long[] moedas, long valor, String descricao) {
        this.moedas = moedas;
        this.valor = valor;
        this.descricao = descricao;
    }

    public long[] getMoedas() {
        return moedas;
    }

    public long getValor() {
        return valor;
    }

    public String getDescricao() {
        return descricao;
    }

    /** Carrega um arquivo JSON no formato {"descricao":..., "moedas":[...], "valor": n}. */
    public static EntradaTroco carregarDeJson(String caminho) throws IOException {
        String conteudo = Files.readString(Path.of(caminho));

        String descricao = extrairCampoTexto(conteudo, "descricao");
        long[] moedas = extrairArrayNumeros(conteudo, "moedas");
        long valor = extrairNumero(conteudo, "valor");

        return new EntradaTroco(moedas, valor, descricao);
    }

    /**
     * Carrega as moedas de um arquivo CSV (uma moeda por linha, primeira
     * linha e cabecalho). O valor a trocar e recebido separadamente, pois
     * o CSV representa apenas o sistema monetario (as moedas disponiveis),
     * nao uma instancia completa do problema.
     */
    public static EntradaTroco carregarDeCsv(String caminho, long valor, String descricao) throws IOException {
        List<String> linhas = Files.readAllLines(Path.of(caminho));
        List<Long> moedas = new ArrayList<>();

        for (int i = 1; i < linhas.size(); i++) { // pula o cabecalho
            String linha = linhas.get(i).trim();
            if (!linha.isEmpty()) {
                moedas.add(Long.parseLong(linha));
            }
        }

        long[] vetor = new long[moedas.size()];
        for (int i = 0; i < vetor.length; i++) {
            vetor[i] = moedas.get(i);
        }

        return new EntradaTroco(vetor, valor, descricao);
    }

    private static String extrairCampoTexto(String json, String chave) {
        Matcher m = Pattern.compile("\"" + chave + "\"\\s*:\\s*\"([^\"]*)\"").matcher(json);
        return m.find() ? m.group(1) : "";
    }

    private static long extrairNumero(String json, String chave) {
        Matcher m = Pattern.compile("\"" + chave + "\"\\s*:\\s*(-?\\d+)").matcher(json);
        if (m.find()) {
            return Long.parseLong(m.group(1));
        }
        throw new IllegalArgumentException("Campo numerico '" + chave + "' nao encontrado no JSON.");
    }

    private static long[] extrairArrayNumeros(String json, String chave) {
        Matcher m = Pattern.compile("\"" + chave + "\"\\s*:\\s*\\[([^\\]]*)\\]").matcher(json);
        if (!m.find()) {
            throw new IllegalArgumentException("Campo array '" + chave + "' nao encontrado no JSON.");
        }
        String[] partes = m.group(1).split(",");
        long[] resultado = new long[partes.length];
        for (int i = 0; i < partes.length; i++) {
            resultado[i] = Long.parseLong(partes[i].trim());
        }
        return resultado;
    }
}
