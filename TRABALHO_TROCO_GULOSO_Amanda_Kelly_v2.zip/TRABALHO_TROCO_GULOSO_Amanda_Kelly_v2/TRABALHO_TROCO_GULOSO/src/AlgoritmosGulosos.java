/**
 * Algoritmos Gulosos - Problema do Troco
 * Disciplina: Analise e Projeto de Algoritmos
 * Equipe: Amanda W. Monzon, Kelly Natasha de O. Fernandes
 *
 * Classe principal: carrega as instancias de teste (pequena, media, grande
 * e um sistema nao-canonico) e executa o algoritmo guloso sobre cada uma,
 * imprimindo o passo a passo das decisoes, a solucao final, o tempo de
 * execucao e, quando viavel, a comparacao com o otimo real (via DP).
 */
public class AlgoritmosGulosos {

    public static void main(String[] args) throws Exception {
        TrocoGuloso guloso = new TrocoGuloso();
        TrocoOtimoDP dp = new TrocoOtimoDP();

        System.out.println("==================================================================");
        System.out.println(" TESTE 1 - PEQUENA INSTANCIA (demonstrar passo a passo)");
        System.out.println("==================================================================");
        EntradaTroco t1 = EntradaTroco.carregarDeJson("entradas/teste1_pequena.json");
        executarEImprimir(guloso, dp, t1, true);

        System.out.println();
        System.out.println("==================================================================");
        System.out.println(" TESTE 2 - MEDIA INSTANCIA (moedas carregadas via CSV)");
        System.out.println("==================================================================");
        EntradaTroco t2 = EntradaTroco.carregarDeCsv(
            "entradas/teste2_media_moedas.csv", 2873, "Teste 2 - media instancia (entrada via CSV)");
        executarEImprimir(guloso, dp, t2, true);

        System.out.println();
        System.out.println("==================================================================");
        System.out.println(" TESTE 3 - GRANDE INSTANCIA (observar eficiencia/desempenho)");
        System.out.println("==================================================================");
        EntradaTroco t3 = EntradaTroco.carregarDeJson("entradas/teste3_grande.json");
        executarEImprimir(guloso, dp, t3, false); // DP desabilitado: inviavel para valor tao grande (O(n*valor))

        System.out.println();
        System.out.println("==================================================================");
        System.out.println(" TESTE EXTRA - SISTEMA NAO CANONICO (guloso pode falhar)");
        System.out.println("==================================================================");
        EntradaTroco t4 = EntradaTroco.carregarDeJson("entradas/teste_nao_canonico.json");
        executarEImprimir(guloso, dp, t4, true);
    }

    private static void executarEImprimir(TrocoGuloso guloso, TrocoOtimoDP dp, EntradaTroco entrada, boolean compararComOtimo) {
        System.out.println("Descricao : " + entrada.getDescricao());
        System.out.println("Moedas    : " + java.util.Arrays.toString(entrada.getMoedas()));
        System.out.println("Valor     : " + entrada.getValor());
        System.out.println("---- decisoes do algoritmo guloso ----");

        TrocoGuloso.Resultado r = guloso.resolver(entrada.getMoedas(), entrada.getValor());
        for (TrocoGuloso.PassoDecisao passo : r.passos) {
            System.out.println("  " + passo);
        }

        System.out.println("---- solucao encontrada ----");
        if (r.conseguiuTrocoExato()) {
            System.out.println("Troco exato! Total de moedas usadas (guloso) = " + r.totalDeMoedasUsadas);
        } else {
            System.out.println("NAO foi possivel dar o troco exato com este sistema de moedas. "
                + "Valor restante sem solucao: " + r.valorRestanteFinal);
        }
        System.out.printf("Tempo de execucao (guloso): %.9f s%n", r.tempoExecucaoNanos / 1_000_000_000.0);

        if (compararComOtimo) {
            TrocoOtimoDP.ResultadoOtimo otimo = dp.resolver(entrada.getMoedas(), entrada.getValor());
            System.out.println("---- verificacao (DP - otimo global real) ----");
            System.out.println("Minimo de moedas (otimo real) = " + otimo.minimoDeMoedas);
            System.out.printf("Tempo de execucao (DP): %.9f s%n", otimo.tempoExecucaoNanos / 1_000_000_000.0);
            if (r.conseguiuTrocoExato()) {
                boolean gulosoFoiOtimo = r.totalDeMoedasUsadas == otimo.minimoDeMoedas;
                System.out.println("O guloso encontrou o OTIMO GLOBAL? " + (gulosoFoiOtimo ? "SIM" : "NAO"));
            }
        }
        System.out.println();
    }
}
