/**
 * Solucao por Programacao Dinamica (bottom-up) do Problema do Troco.
 *
 * IMPORTANTE: esta classe NAO e o algoritmo escolhido para o trabalho —
 * ela existe apenas como METODO DE VERIFICACAO, para comparar o resultado
 * do algoritmo guloso (TrocoGuloso) com o otimo global real e assim
 * responder, na Analise Critica, se a escolha gulosa local leva ou nao
 * ao otimo global. E uma implementacao propria (escrita por nos), nao
 * uma biblioteca pronta.
 *
 * Complexidade: O(n * valor) em tempo e espaco (pseudo-polinomial),
 * por isso so e viavel para valores pequenos/medios — o que, por si so,
 * ja e um dado relevante para a analise de complexidade do trabalho.
 */
public class TrocoOtimoDP {

    public static class ResultadoOtimo {
        public final long minimoDeMoedas; // -1 se nao houver solucao exata
        public final long tempoExecucaoNanos;

        ResultadoOtimo(long minimoDeMoedas, long tempoExecucaoNanos) {
            this.minimoDeMoedas = minimoDeMoedas;
            this.tempoExecucaoNanos = tempoExecucaoNanos;
        }
    }

    public ResultadoOtimo resolver(long[] moedas, long valor) {
        long inicio = System.nanoTime();

        int v = (int) valor;
        long[] dp = new long[v + 1];
        java.util.Arrays.fill(dp, Long.MAX_VALUE / 2);
        dp[0] = 0;

        for (int i = 1; i <= v; i++) {
            for (long moeda : moedas) {
                if (moeda <= i) {
                    dp[i] = Math.min(dp[i], dp[(int) (i - moeda)] + 1);
                }
            }
        }

        long tempo = System.nanoTime() - inicio;
        long minimo = dp[v] >= Long.MAX_VALUE / 2 ? -1 : dp[v];
        return new ResultadoOtimo(minimo, tempo);
    }
}
